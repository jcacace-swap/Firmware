/****************************************************************************
 *
 *   Copyright (c) 2013-2018 PX4 Development Team. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name PX4 nor the names of its contributors may be
 *    used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/

#include <lib/mixer/mixer.h>
#include <mathlib/math/filter/LowPassFilter2p.hpp>
#include <matrix/matrix/math.hpp>
#include <perf/perf_counter.h>
#include <px4_config.h>
#include <px4_defines.h>
#include <px4_module.h>
#include <px4_module_params.h>
#include <px4_posix.h>
#include <px4_tasks.h>
#include <uORB/topics/actuator_controls.h>
#include <uORB/topics/battery_status.h>
#include <uORB/topics/manual_control_setpoint.h>
#include <uORB/topics/multirotor_motor_limits.h>
#include <uORB/topics/parameter_update.h>
#include <uORB/topics/rate_ctrl_status.h>
#include <uORB/topics/sensor_bias.h>
#include <uORB/topics/sensor_correction.h>
#include <uORB/topics/sensor_gyro.h>
#include <uORB/topics/vehicle_attitude.h>
#include <uORB/topics/vehicle_attitude_setpoint.h>
#include <uORB/topics/vehicle_control_mode.h>
#include <uORB/topics/vehicle_rates_setpoint.h>
#include <uORB/topics/vehicle_status.h>
#include <uORB/topics/vehicle_land_detected.h>
#include <uORB/topics/vehicle_local_position_setpoint.h>
#include <uORB/topics/vehicle_local_position.h>
#include <uORB/topics/vehicle_local_position_setpoint.h>



/**
 * Multicopter attitude control app start / stop handling function
 */
extern "C" __EXPORT int mc_sm_att_control_main(int argc, char *argv[]);

#define MAX_GYRO_COUNT 3


class MulticopterSMAttitudeControl : public ModuleBase<MulticopterSMAttitudeControl>, public ModuleParams
{
public:
	MulticopterSMAttitudeControl();

	virtual ~MulticopterSMAttitudeControl() = default;

	/** @see ModuleBase */
	static int task_spawn(int argc, char *argv[]);

	/** @see ModuleBase */
	static MulticopterSMAttitudeControl *instantiate(int argc, char *argv[]);

	/** @see ModuleBase */
	static int custom_command(int argc, char *argv[]);

	/** @see ModuleBase */
	static int print_usage(const char *reason = nullptr);

	void eulerFromQuat( float q[4], float & roll, float & pitch, float & yaw );
	
	/** @see ModuleBase::run() */
	void run() override;

private:

	/**
	 * initialize some vectors/matrices from parameters
	 */
	void			parameters_updated();

	/**
	 * Check for parameter update and handle it.
	 */
	void		battery_status_poll();
	void		parameter_update_poll();
	void		sensor_bias_poll();
	void		vehicle_land_detected_poll();
	void		sensor_correction_poll();
	void		vehicle_attitude_poll();
	void		vehicle_attitude_setpoint_poll();
	void		vehicle_control_mode_poll();
	void		vehicle_manual_poll();
	void		vehicle_motor_limits_poll();
	void		vehicle_rates_setpoint_poll();
	void		vehicle_status_poll();
	void 		local_position_sp_poll();
	void 		local_position_poll();

	/**
	 * Attitude controller.
	 */
	void		control_attitude(float dt);
	void		control_attitude_sm(float dt);

	/**
	 * Attitude rates controller.
	 */
	void		control_attitude_rates(float dt);

	/**
	 * Throttle PID attenuation.
	 */
	matrix::Vector3f pid_attenuations(float tpa_breakpoint, float tpa_rate);


	int		_v_att_sub{-1};			/**< vehicle attitude subscription */
	int		_v_att_sp_sub{-1};		/**< vehicle attitude setpoint subscription */
	int		_v_rates_sp_sub{-1};		/**< vehicle rates setpoint subscription */
	int		_v_control_mode_sub{-1};	/**< vehicle control mode subscription */
	int		_params_sub{-1};		/**< parameter updates subscription */
	int		_manual_control_sp_sub{-1};	/**< manual control setpoint subscription */
	int		_vehicle_status_sub{-1};	/**< vehicle status subscription */
	int		_motor_limits_sub{-1};		/**< motor limits subscription */
	int		_battery_status_sub{-1};	/**< battery status subscription */
	int		_sensor_gyro_sub[MAX_GYRO_COUNT];	/**< gyro data subscription */
	int		_sensor_correction_sub{-1};	/**< sensor thermal correction subscription */
	int		_sensor_bias_sub{-1};		/**< sensor in-run bias correction subscription */
	int		_vehicle_land_detected_sub{-1};	/**< vehicle land detected subscription */

	int		_local_position_sub{-1};			/**< vehicle local position */
	int 	_local_position_sp_sub{-1}; 	/**< local position setpoint */

	unsigned _gyro_count{1};
	int _selected_gyro{0};

	orb_advert_t	_v_rates_sp_pub{nullptr};		/**< rate setpoint publication */
	orb_advert_t	_actuators_0_pub{nullptr};		/**< attitude actuator controls publication */
	orb_advert_t	_controller_status_pub{nullptr};	/**< controller status publication */

	orb_id_t _rates_sp_id{nullptr};		/**< pointer to correct rates setpoint uORB metadata structure */
	orb_id_t _actuators_id{nullptr};	/**< pointer to correct actuator controls0 uORB metadata structure */

	bool		_actuators_0_circuit_breaker_enabled{false};	/**< circuit breaker to suppress output */

	struct vehicle_attitude_s		_v_att {};		/**< vehicle attitude */
	struct vehicle_attitude_setpoint_s	_v_att_sp {};		/**< vehicle attitude setpoint */
	struct vehicle_rates_setpoint_s		_v_rates_sp {};		/**< vehicle rates setpoint */
	struct manual_control_setpoint_s	_manual_control_sp {};	/**< manual control setpoint */
	struct vehicle_control_mode_s		_v_control_mode {};	/**< vehicle control mode */
	struct actuator_controls_s		_actuators {};		/**< actuator controls */
	struct vehicle_status_s			_vehicle_status {};	/**< vehicle status */
	struct battery_status_s			_battery_status {};	/**< battery status */
	struct sensor_gyro_s			_sensor_gyro {};	/**< gyro data before thermal correctons and ekf bias estimates are applied */
	struct sensor_correction_s		_sensor_correction {};	/**< sensor thermal corrections */
	struct sensor_bias_s			_sensor_bias {};	/**< sensor in-run bias corrections */
	struct vehicle_land_detected_s		_vehicle_land_detected {};
	struct vehicle_local_position_setpoint_s _vehicle_setponit{};
	struct vehicle_local_position_s		_local_pos{};			/**< vehicle local position */

	MultirotorMixer::saturation_status _saturation_status{};

	perf_counter_t	_loop_perf;			/**< loop performance counter */

	math::LowPassFilter2p _lp_filters_d[3];                      /**< low-pass filters for D-term (roll, pitch & yaw) */
	static constexpr const float initial_update_rate_hz = 250.f; /**< loop update rate used for initialization */
	float _loop_update_rate_hz{initial_update_rate_hz};          /**< current rate-controller loop update rate in [Hz] */

	matrix::Vector3f _rates_prev;			/**< angular rates on previous step */
	matrix::Vector3f _rates_prev_filtered;		/**< angular rates on previous step (low-pass filtered) */
	matrix::Vector3f _rates_sp;			/**< angular rates setpoint */
	matrix::Vector3f _rates_int;			/**< angular rates integral error */
	float _thrust_sp;				/**< thrust setpoint */
	matrix::Vector3f _att_control;			/**< attitude control vector */

	matrix::Dcmf _board_rotation;			/**< rotation matrix for the orientation that the board is mounted */

	DEFINE_PARAMETERS(
		
		(ParamInt<px4::params::SENS_BOARD_ROT>) _board_rotation_param,
		(ParamFloat<px4::params::SM_DTERM_CUTOFF>) _d_term_cutoff_freq,			
		(ParamFloat<px4::params::SENS_BOARD_X_OFF>) _board_offset_x,
		(ParamFloat<px4::params::SENS_BOARD_Y_OFF>) _board_offset_y,
		(ParamFloat<px4::params::SENS_BOARD_Z_OFF>) _board_offset_z,
		
		//Controller parameters
		(ParamFloat<px4::params::SM_MU_X>) _mu_x, 
		(ParamFloat<px4::params::SM_MU_Y>) _mu_y, 
		(ParamFloat<px4::params::SM_MU_Z>) _mu_z, 
		(ParamFloat<px4::params::SM_BETA_X>) _beta_x, 
		(ParamFloat<px4::params::SM_BETA_Y>) _beta_y, 
		(ParamFloat<px4::params::SM_BETA_Z>) _beta_z, 
		(ParamFloat<px4::params::SM_LAMBDA_X>) _lambda_x, 
		(ParamFloat<px4::params::SM_LAMBDA_Y>) _lambda_y, 
		(ParamFloat<px4::params::SM_LAMBDA_Z>) _lambda_z, 
		(ParamFloat<px4::params::SM_BETA_PHI>) _beta_phi, 
		(ParamFloat<px4::params::SM_BETA_THETA>) _beta_theta, 
		(ParamFloat<px4::params::SM_BETA_PSI>) _beta_psi, 
		(ParamFloat<px4::params::SM_MU_PHI>) _mu_phi, 
		(ParamFloat<px4::params::SM_MU_THETA>) _mu_theta, 
		(ParamFloat<px4::params::SM_MU_PSI>) _mu_psi,
		
		(ParamFloat<px4::params::SM_ALLOC_BF>)  _bf,
		(ParamFloat<px4::params::SM_ALLOC_L>) _l,
		(ParamFloat<px4::params::SM_ALLOC_BM>) _bm,
		(ParamFloat<px4::params::SM_ALLOC_M>) _m,
		(ParamFloat<px4::params::SM_ALLOC_G>) _g,
		(ParamFloat<px4::params::SM_ALLOC_IX>) _Ix,
		(ParamFloat<px4::params::SM_ALLOC_IY>) _Iy,
		(ParamFloat<px4::params::SM_ALLOC_IZ>) _Iz,
		(ParamFloat<px4::params::TEST_M_S>) _spin,

		(ParamFloat<px4::params::SM_T_KP>) _sm_t_kp,
		(ParamFloat<px4::params::SM_T_KD>) _sm_t_kd,
		(ParamFloat<px4::params::SM_T_KI>) _sm_t_ki


	)
	

	matrix::Vector3f _attitude_p;		/**< P gain for attitude control */
	matrix::Vector3f _rate_p;		/**< P gain for angular rate error */
	matrix::Vector3f _rate_i;		/**< I gain for angular rate error */
	matrix::Vector3f _rate_int_lim;		/**< integrator state limit for rate loop */
	matrix::Vector3f _rate_d;		/**< D gain for angular rate error */
	matrix::Vector3f _rate_ff;		/**< Feedforward gain for desired rates */

	matrix::Vector3f _mc_rate_max;		/**< attitude rate limits in stabilized modes */
	matrix::Vector3f _auto_rate_max;	/**< attitude rate limits in auto modes */
	matrix::Vector3f _acro_rate_max;	/**< max attitude rates in acro mode */


	//Controller gains
	float beta_x_, beta_y_, beta_z_;
	float beta_phi_, beta_theta_, beta_psi_;

	float alpha_x_, alpha_y_, alpha_z_;
	float alpha_phi_, alpha_theta_, alpha_psi_;

	float mu_x_, mu_y_, mu_z_;
	float mu_phi_, mu_theta_, mu_psi_;

	float lambda_x_, lambda_y_, lambda_z_;
	float K_x_1_, K_x_2_;
	float K_y_1_, K_y_2_;
	float K_z_1_, K_z_2_;

	//Vehicle parameters
	float bf_, m_, g_;
	float l_, bm_;
	float Ix_, Iy_, Iz_;

	float ei_x_ = 0.0f;
	float ei_y_ = 0.0f;
	float ei_z_ = 0.0f;

	float e_x_p_ = 0.0f;
	float e_y_p_ = 0.0f;
	float e_z_p_ = 0.0f;


};

