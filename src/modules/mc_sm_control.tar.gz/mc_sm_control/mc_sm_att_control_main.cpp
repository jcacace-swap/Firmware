/****************************************************************************
 *
 *   Copyright (c) 2013-2018 PX4 Development Team. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name PX4 nor the names of its contributors may be
 *    used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/

/**
 * @file mc_att_control_main.cpp
 * Multicopter attitude controller.
 *
 * @author Lorenz Meier		<lorenz@px4.io>
 * @author Anton Babushkin	<anton.babushkin@me.com>
 * @author Sander Smeets	<sander@droneslab.com>
 * @author Matthias Grob	<maetugr@gmail.com>
 * @author Beat Küng		<beat-kueng@gmx.net>
 *
 */

#include "mc_sm_att_control.hpp"

#include <conversion/rotation.h>
#include <drivers/drv_hrt.h>
#include <lib/ecl/geo/geo.h>
#include <circuit_breaker/circuit_breaker.h>
#include <mathlib/math/Limits.hpp>
#include <mathlib/math/Functions.hpp>



#define TPA_RATE_LOWER_LIMIT 0.05f

#define AXIS_INDEX_ROLL 0
#define AXIS_INDEX_PITCH 1
#define AXIS_INDEX_YAW 2
#define AXIS_COUNT 3

#define MAX_ROTOR_VELOCITY        1100 /* Max rotors velocity [rad/s] */
#define MIN_ROTOR_VELOCITY        0 /* Min rotors velocity [rad/s] */
#define POW_MAX_ROTOR_VELOCITY    MAX_ROTOR_VELOCITY*MAX_ROTOR_VELOCITY /* Squared max rotors velocity [rad/s] */


using namespace matrix;


int MulticopterSMAttitudeControl::print_usage(const char *reason)
{
	if (reason) {
		PX4_WARN("%s\n", reason);
	}

	PRINT_MODULE_DESCRIPTION(
		R"DESCR_STR(
		### Description
		This implements the multicopter attitude and rate controller. It takes attitude
		setpoints (`vehicle_attitude_setpoint`) or rate setpoints (in acro mode
		via `manual_control_setpoint` topic) as inputs and outputs actuator control messages.

		The controller has two loops: a P loop for angular error and a PID loop for angular rate error.

		Publication documenting the implemented Quaternion Attitude Control:
		Nonlinear Quadrocopter Attitude Control (2013)
		by Dario Brescianini, Markus Hehn and Raffaello D'Andrea
		Institute for Dynamic Systems and Control (IDSC), ETH Zurich

		https://www.research-collection.ethz.ch/bitstream/handle/20.500.11850/154099/eth-7387-01.pdf

		### Implementation
		To reduce control latency, the module directly polls on the gyro topic published by the IMU driver.

		)DESCR_STR");

	PRINT_MODULE_USAGE_NAME("mc_att_control", "controller");
	PRINT_MODULE_USAGE_COMMAND("start");
	PRINT_MODULE_USAGE_DEFAULT_COMMANDS();

	return 0;
}

MulticopterSMAttitudeControl::MulticopterSMAttitudeControl() :
	ModuleParams(nullptr),
	_loop_perf(perf_alloc(PC_ELAPSED, "mc_att_control")),
	_lp_filters_d{
	{initial_update_rate_hz, 50.f},
	{initial_update_rate_hz, 50.f},
	{initial_update_rate_hz, 50.f}} // will be initialized correctly when params are loaded
{
	for (uint8_t i = 0; i < MAX_GYRO_COUNT; i++) {
		_sensor_gyro_sub[i] = -1;
	}

	_vehicle_status.is_rotary_wing = true;

	/* initialize quaternions in messages to be valid */
	_v_att.q[0] = 1.f;
	_v_att_sp.q_d[0] = 1.f;

	_rates_prev.zero();
	_rates_prev_filtered.zero();
	_rates_sp.zero();
	_rates_int.zero();
	_thrust_sp = 0.0f;
	_att_control.zero();

	/* initialize thermal corrections as we might not immediately get a topic update (only non-zero values) */
	for (unsigned i = 0; i < 3; i++) {
		// used scale factors to unity
		_sensor_correction.gyro_scale_0[i] = 1.0f;
		_sensor_correction.gyro_scale_1[i] = 1.0f;
		_sensor_correction.gyro_scale_2[i] = 1.0f;
	}

	//---Init parameters



	
	parameters_updated();	
}

void
MulticopterSMAttitudeControl::parameters_updated()
{
	/* get transformation matrix from sensor/board to body frame */
	_board_rotation = get_rot_matrix((enum Rotation)_board_rotation_param.get());
	
	//---control parameters initialization
	mu_x_ = _mu_x.get();
	mu_y_ = _mu_y.get();
	mu_z_ = _mu_z.get();
	beta_x_ = _beta_x.get();
	beta_y_ = _beta_y.get();
	beta_z_ = _beta_z.get();
	lambda_x_ = _lambda_x.get();
	lambda_y_ = _lambda_y.get();
	lambda_z_ = _lambda_z.get();
	beta_phi_ = _beta_phi.get();
	beta_theta_ = _beta_theta.get();
	beta_psi_ = _beta_psi.get();
	mu_phi_ = _mu_phi.get();
	mu_theta_ = _mu_theta.get();
	mu_psi_ = _mu_psi.get();

	K_x_1_ = 1.0f/mu_x_;
  	K_x_2_ = -2.0f * (beta_x_/mu_x_);
	K_y_1_ = 1.0f/mu_y_;
  	K_y_2_ = -2.0f * (beta_y_/mu_y_);
	K_z_1_ = 1.0f/mu_z_;
  	K_z_2_ = -2.0f * (beta_z_/mu_z_);
	
	alpha_x_ = 1.0f - beta_x_;
	alpha_y_ = 1.0f - beta_y_;
	alpha_z_ = 1.0f - beta_z_;

	alpha_phi_ = 1.0f - beta_phi_;
	alpha_theta_ = 1.0f - beta_theta_;
	alpha_psi_ = 1.0f - beta_psi_;
	//---

	//---Allocation parameters
	bf_ = _bf.get();
	l_  =_l.get(); 
	bm_ = _bm.get();
	m_  = _m.get();
	g_  = _g.get();
	Ix_ = _Ix.get();
	Iy_ = _Iy.get();
	Iz_ = _Iz.get();
	//---


	/* fine tune the rotation */
	Dcmf board_rotation_offset(Eulerf(
			M_DEG_TO_RAD_F * _board_offset_x.get(),
			M_DEG_TO_RAD_F * _board_offset_y.get(),
			M_DEG_TO_RAD_F * _board_offset_z.get()));
	_board_rotation = board_rotation_offset * _board_rotation;
}

void
MulticopterSMAttitudeControl::parameter_update_poll()
{
	bool updated;

	/* Check if parameters have changed */
	orb_check(_params_sub, &updated);

	if (updated) {
		struct parameter_update_s param_update;
		orb_copy(ORB_ID(parameter_update), _params_sub, &param_update);
		updateParams();
		parameters_updated();
	}
}

void
MulticopterSMAttitudeControl::vehicle_control_mode_poll()
{
	bool updated;

	/* Check if vehicle control mode has changed */
	orb_check(_v_control_mode_sub, &updated);

	if (updated) {
		orb_copy(ORB_ID(vehicle_control_mode), _v_control_mode_sub, &_v_control_mode);
	}
}

void
MulticopterSMAttitudeControl::vehicle_manual_poll()
{
	bool updated;

	/* get pilots inputs */
	orb_check(_manual_control_sp_sub, &updated);

	if (updated) {
		orb_copy(ORB_ID(manual_control_setpoint), _manual_control_sp_sub, &_manual_control_sp);
	}
}

void
MulticopterSMAttitudeControl::vehicle_attitude_setpoint_poll()
{
	/* check if there is a new setpoint */
	bool updated;
	orb_check(_v_att_sp_sub, &updated);

	if (updated) {
		orb_copy(ORB_ID(vehicle_attitude_setpoint), _v_att_sp_sub, &_v_att_sp);
	
	}
}

void
MulticopterSMAttitudeControl::vehicle_rates_setpoint_poll()
{
	/* check if there is a new setpoint */
	bool updated;
	orb_check(_v_rates_sp_sub, &updated);

	if (updated) {
		orb_copy(ORB_ID(vehicle_rates_setpoint), _v_rates_sp_sub, &_v_rates_sp);
	}
}

void
MulticopterSMAttitudeControl::vehicle_status_poll()
{
	/* check if there is new status information */
	bool vehicle_status_updated;
	orb_check(_vehicle_status_sub, &vehicle_status_updated);

	if (vehicle_status_updated) {
		orb_copy(ORB_ID(vehicle_status), _vehicle_status_sub, &_vehicle_status);

		/* set correct uORB ID, depending on if vehicle is VTOL or not */
		if (_rates_sp_id == nullptr) {
			if (_vehicle_status.is_vtol) {
				_rates_sp_id = ORB_ID(mc_virtual_rates_setpoint);
				_actuators_id = ORB_ID(actuator_controls_virtual_mc);

			} else {
				_rates_sp_id = ORB_ID(vehicle_rates_setpoint);
				_actuators_id = ORB_ID(actuator_controls_0);
			}
		}
	}
}

void
MulticopterSMAttitudeControl::local_position_sp_poll()
{
	bool local_setpoint_updated;
	orb_check(_local_position_sp_sub, &local_setpoint_updated);

	if( local_setpoint_updated ) {
		orb_copy(ORB_ID(vehicle_local_position_setpoint), _local_position_sp_sub, &_vehicle_setponit);
		//printf("Setpoint: %f %f %f\n", (double)_vehicle_setponit.x, (double)_vehicle_setponit.y, (double)_vehicle_setponit.z);
	}
}

void
MulticopterSMAttitudeControl::local_position_poll()
{
	
	bool local_position_updated;
	orb_check(_local_position_sub, &local_position_updated);

	if( local_position_updated ) {
		orb_copy(ORB_ID(vehicle_local_position), _local_position_sub, &_local_pos);
		//printf("Position: %f %f %f\n", (double)_local_pos.x, (double)_local_pos.y, (double)_local_pos.z);
	}
}

void
MulticopterSMAttitudeControl::vehicle_motor_limits_poll()
{
	/* check if there is a new message */
	bool updated;
	orb_check(_motor_limits_sub, &updated);

	if (updated) {
		multirotor_motor_limits_s motor_limits = {};
		orb_copy(ORB_ID(multirotor_motor_limits), _motor_limits_sub, &motor_limits);

		_saturation_status.value = motor_limits.saturation_status;
	}
}

void
MulticopterSMAttitudeControl::battery_status_poll()
{
	/* check if there is a new message */
	bool updated;
	orb_check(_battery_status_sub, &updated);

	if (updated) {
		orb_copy(ORB_ID(battery_status), _battery_status_sub, &_battery_status);
	}
}

void
MulticopterSMAttitudeControl::vehicle_attitude_poll()
{
	/* check if there is a new message */
	bool updated;
	orb_check(_v_att_sub, &updated);

	if (updated) {
		orb_copy(ORB_ID(vehicle_attitude), _v_att_sub, &_v_att);
	}
}

void
MulticopterSMAttitudeControl::sensor_correction_poll()
{
	/* check if there is a new message */
	bool updated;
	orb_check(_sensor_correction_sub, &updated);

	if (updated) {
		orb_copy(ORB_ID(sensor_correction), _sensor_correction_sub, &_sensor_correction);
	}

	/* update the latest gyro selection */
	if (_sensor_correction.selected_gyro_instance < _gyro_count) {
		_selected_gyro = _sensor_correction.selected_gyro_instance;
	}
}

void
MulticopterSMAttitudeControl::sensor_bias_poll()
{
	/* check if there is a new message */
	bool updated;
	orb_check(_sensor_bias_sub, &updated);

	if (updated) {
		orb_copy(ORB_ID(sensor_bias), _sensor_bias_sub, &_sensor_bias);
	}

}

void
MulticopterSMAttitudeControl::vehicle_land_detected_poll()
{
	/* check if there is a new message */
	bool updated;
	orb_check(_vehicle_land_detected_sub, &updated);

	if (updated) {
		orb_copy(ORB_ID(vehicle_land_detected), _vehicle_land_detected_sub, &_vehicle_land_detected);
	}
}



void MulticopterSMAttitudeControl::eulerFromQuat( float q[4], float & roll, float & pitch, float & yaw ) {

	double qw = q[0];
	double qx = q[1];
	double qy = q[2];
	double qz = q[3];

	//printf("Att: %f %f %f %f\n", (double)qw, (double)qx, (double)qy, (double)qz);

	roll =  atan2(2.0*(qy*qz + qw*qx), qw*qw - qx*qx - qy*qy + qz*qz);
	pitch = asin(-2.0*(qx*qz - qw*qy));
	yaw = atan2(2.0*(qx*qy + qw*qz), qw*qw + qx*qx - qy*qy - qz*qz);
	//printf("EUler: %f %f %f\n", (double)roll, (double)pitch, (double)yaw);

}
/**
 * Attitude controller.
 * Input: 'vehicle_attitude_setpoint', 'vehicle_local_sp', 'vehicle_local_position' topics
 * Output: 'Force and moments' vector
 */
void
MulticopterSMAttitudeControl::control_attitude_sm(float dt) {

	local_position_poll();

	if( _v_control_mode.flag_armed ) {
		
		float e_x_ = _vehicle_setponit.x - _local_pos.x;
		float e_y_ = _vehicle_setponit.y - _local_pos.y;
		float e_z_ = _vehicle_setponit.z - _local_pos.z;

		float dot_e_x_ = _vehicle_setponit.vx;
		float dot_e_y_ = _vehicle_setponit.vy;
		float dot_e_z_ = _vehicle_setponit.vz;

		float mu[3];
		mu[0] = _sm_t_kp.get()*e_x_ + _sm_t_kd.get()*dot_e_x_;
		mu[1] = _sm_t_kp.get()*e_y_ + _sm_t_kd.get()*dot_e_y_;
		mu[2] = _sm_t_kp.get()*e_z_ + _sm_t_kd.get()*dot_e_z_;

		float u_T = m_ * sqrt ( mu[0]*mu[0] + mu[1]*mu[1] + ( mu[2]-g_)*(mu[2]-g_));
		u_T = u_T / 16.78f;
		_thrust_sp = _v_att_sp.thrust;
		printf("ex: %f - ey: %f - ez: %f Thrust: %f\n", (double)e_x_, (double)e_y_, (double)e_z_, (double)u_T);
		/*
		float u_x = ( (e_x_ * K_x_1_ * K_x_2_)/lambda_x_ ) + ( (dot_e_x_ * K_x_2_)/lambda_x_ );
		
		if ( u_x > 1 || u_x <-1) {
			u_x = ( u_x > 1 ) ? 1.0 : -1.0;
		}

		u_x = (u_x * 1/2) + ( (K_x_1_/lambda_x_) * dot_e_x_ );

		if ( u_x > 1 ||  u_x <-1) {
			u_x = ( u_x > 1 ) ? 1.0 : -1.0;
		}

		u_x = m_ * ( u_x * lambda_x_);

		//u_y computing
		float u_y = ( (e_y_ * K_y_1_ * K_y_2_)/lambda_y_ ) + ( (dot_e_y_ * K_y_2_)/lambda_y_ );

		if ( u_y > 1 ||  u_y <-1) {
			u_y = ( u_y > 1 ) ? 1.0 : -1.0;
		}

		u_y = (u_y * 1/2) + ( (K_y_1_/lambda_y_) * dot_e_y_ );

		if ( u_y > 1 ||  u_y <-1) {
			u_y = ( u_y > 1 ) ? 1.0 : -1.0;
		}

		u_y = m_* ( u_y * lambda_y_);

		//u_z computing
		float u_z = ( (e_z_ * K_z_1_ * K_z_2_)/lambda_z_ ) + ( (dot_e_z_ * K_z_2_)/lambda_z_ );

		//printf("e_z: %f - u_z: %f\n", (double)e_z_, (double)u_z );
		if ( u_z > 1 ||  u_z <-1) {
			u_z = ( u_z > 1 ) ? 1.0 : -1.0;
		}
		

		u_z = (u_z * 1/2) + ( (K_z_1_/lambda_z_) * dot_e_z_ );

		if ( u_z > 1 ||  u_z <-1) {
			u_z = ( u_z > 1 ) ? 1.0 : -1.0;
		}

		u_z = m_* ( u_z * lambda_z_);

		//u_Terr computing
		float u_Terr = u_z + (m_ * g_);

		//printf("u_z: %f - U_TERR: %f\n", (double)u_z, (double)u_Terr);
		//u_T computing
		float u_T = sqrt( pow(u_x,2) + pow(u_y,2) + pow(u_Terr,2) );

		printf("u_T: %f\n", (double)u_T);

		//u_T /= 10.0f; //max 20 newton

		//u_T = (0.4f/4.9f) * u_T;
		vehicle_attitude_setpoint_poll();
		//_thrust_sp = _v_att_sp.thrust - u_T;
		//_thrust_sp = u_T;
		u_T = u_T / 16.78f;
		_thrust_sp = u_T; //_v_att_sp.thrust;
		
		
		printf("Sat: %f - setpoint: %f\n", (double)_thrust_sp, (double)u_T);
		*/
		_thrust_sp = _v_att_sp.thrust; //_v_att_sp.thrust;

		float roll, pitch, yaw;
		float dot_e_phi_, dot_e_theta_, dot_e_psi_;

		//double u_phi, u_theta, u_psi;
		eulerFromQuat(_v_att.q, roll, pitch, yaw);

		//Attitude error
		float e_phi_ =  _v_att_sp.roll_body - roll;
		float e_theta_ =  _v_att_sp.pitch_body - pitch;
		float e_psi_ = _v_att_sp.yaw_body - yaw;


		//Angular velocity erorr
		//double psi_r = _v_att_sp.yaw_body;
		double dot_phi, dot_theta, dot_psi;

		// get the raw gyro data and correct for thermal errors
		Vector3f rates;

		if (_selected_gyro == 0) {
			rates(0) = (_sensor_gyro.x - _sensor_correction.gyro_offset_0[0]) * _sensor_correction.gyro_scale_0[0];
			rates(1) = (_sensor_gyro.y - _sensor_correction.gyro_offset_0[1]) * _sensor_correction.gyro_scale_0[1];
			rates(2) = (_sensor_gyro.z - _sensor_correction.gyro_offset_0[2]) * _sensor_correction.gyro_scale_0[2];

		} else if (_selected_gyro == 1) {
			rates(0) = (_sensor_gyro.x - _sensor_correction.gyro_offset_1[0]) * _sensor_correction.gyro_scale_1[0];
			rates(1) = (_sensor_gyro.y - _sensor_correction.gyro_offset_1[1]) * _sensor_correction.gyro_scale_1[1];
			rates(2) = (_sensor_gyro.z - _sensor_correction.gyro_offset_1[2]) * _sensor_correction.gyro_scale_1[2];

		} else if (_selected_gyro == 2) {
			rates(0) = (_sensor_gyro.x - _sensor_correction.gyro_offset_2[0]) * _sensor_correction.gyro_scale_2[0];
			rates(1) = (_sensor_gyro.y - _sensor_correction.gyro_offset_2[1]) * _sensor_correction.gyro_scale_2[1];
			rates(2) = (_sensor_gyro.z - _sensor_correction.gyro_offset_2[2]) * _sensor_correction.gyro_scale_2[2];

		} else {
			rates(0) = _sensor_gyro.x;
			rates(1) = _sensor_gyro.y;
			rates(2) = _sensor_gyro.z;
		}

		dot_phi = rates(0) + (sin(roll) * tan(pitch) * rates(1)) + (cos( roll  ) * tan( pitch ) * rates(2));
		dot_theta = (cos( roll ) * rates(1)) - (sin( roll ) * rates(2));
		dot_psi = ( ( sin( roll ) * rates(1)) / cos(pitch) ) + ( ( cos( roll ) * rates(2)) / cos(pitch) );
		
		dot_e_phi_ =  - dot_phi;
		dot_e_theta_ = - dot_theta;
		dot_e_psi_ = - dot_psi;

		//---Attitude control
		float u_phi = Ix_ * ( ( ( (alpha_phi_/mu_phi_    ) * dot_e_phi_  ) - ( (beta_phi_/float(pow(mu_phi_,2))    ) * e_phi_  ) ) - ( ( (Iy_ - Iz_)/(Ix_ * mu_theta_ * mu_psi_) ) * e_theta_ * e_psi_) );
		float u_theta = Iy_ * ( ( ( (alpha_theta_/mu_theta_) * dot_e_theta_) - ( (beta_theta_/float(pow(mu_theta_,2))) * e_theta_) ) - ( ( (Iz_ - Ix_)/(Iy_ * mu_phi_ * mu_psi_  ) ) * e_phi_   * e_psi_) );
		float u_psi = Iz_ *   ( ( ( (alpha_psi_/mu_psi_    ) * dot_e_psi_  ) - ( (beta_psi_/float(pow(mu_psi_,2))    ) * e_psi_  ) ) - ( ( (Ix_ - Iy_)/(Iz_ * mu_theta_ * mu_phi_) ) * e_theta_ * e_phi_) );
		//---

		_actuators.control[0] = (PX4_ISFINITE(u_phi)) ? u_phi : 0.0f;
		_actuators.control[1] = (PX4_ISFINITE(u_theta)) ? u_theta : 0.0f;
		_actuators.control[2] = (PX4_ISFINITE(u_psi)) ? u_psi : 0.0f;
		_actuators.control[3] = (PX4_ISFINITE(_thrust_sp)) ? _thrust_sp : 0.0f;
		_actuators.control[7] = _v_att_sp.landing_gear;
		
		_actuators.timestamp = hrt_absolute_time();
		_actuators.timestamp_sample = _sensor_gyro.timestamp;
		
		if (!_actuators_0_circuit_breaker_enabled) {
			if (_actuators_0_pub != nullptr) {

				orb_publish(_actuators_id, _actuators_0_pub, &_actuators);

			} else if (_actuators_id) {
				_actuators_0_pub = orb_advertise(_actuators_id, &_actuators);
			}

		}
		
		/*
		float first, second, third, fourth;
		first = (1.0f / ( 4.0f * bf_ )) * _v_att_sp.thrust;
		second = (1.0f / (4.0f * bf_ * l_ * cos(3.1415f/4.0f) ) ) * u_phi;
		third = (1.0f / (4.0f * bf_ * l_ * cos(3.1415f/4.0f) ) ) * u_theta;
		fourth = (1.0f / ( 4.0f * bf_ * bm_)) * u_psi;
	
		float not_saturated_1, not_saturated_2, not_saturated_3, not_saturated_4;
		not_saturated_1 = first - second - third - fourth;
		not_saturated_2 = first + second - third + fourth;
		not_saturated_3 = first + second + third - fourth;
		not_saturated_4 = first - second + third + fourth;
		*/
		/*
		// The propellers velocities is limited by taking into account the physical constrains
		float motorMin=not_saturated_1, motorMax=not_saturated_1, motorFix=0;

		if(not_saturated_2 < motorMin) motorMin = not_saturated_2;
		if(not_saturated_2 > motorMax) motorMax = not_saturated_2;

		if(not_saturated_3 < motorMin) motorMin = not_saturated_3;
		if(not_saturated_3 > motorMax) motorMax = not_saturated_3;

		if(not_saturated_4 < motorMin) motorMin = not_saturated_4;
		if(not_saturated_4 > motorMax) motorMax = not_saturated_4;

		
		if(motorMin < MIN_ROTOR_VELOCITY) motorFix = MIN_ROTOR_VELOCITY - motorMin;
		else if(motorMax > POW_MAX_ROTOR_VELOCITY) motorFix = POW_MAX_ROTOR_VELOCITY - motorMax;
		
		not_saturated_1 = not_saturated_1 + motorFix;
		not_saturated_2 = not_saturated_2 + motorFix;
		not_saturated_3 = not_saturated_3 + motorFix;
		not_saturated_4 = not_saturated_4 + motorFix;
		*/
		
		//printf("Forces: %f %f %f\n", (double)u_phi, (double)u_theta, (double)u_psi);
		//printf("Rates: %f %f %f\n", (double)_att_control(0), (double)_att_control(1), (double)_att_control(2));


		//printf("Rates diff: %f %f %f\n", (double)fabs( u_phi -_att_control(0) ) , (double) fabs( u_theta - _att_control(1) ), (double)fabs( u_psi - _att_control(2)) );
		//printf("Thrust setpoin: %f - %f\n", (double)v_att_sp.thrust, )


		/*
		printf("z: %f\n", (double)_local_pos.z );
		

		_actuators.control[0] = (PX4_ISFINITE(0.0f)) ? 0.0f : 0.0f;
		_actuators.control[1] = (PX4_ISFINITE(0.0f)) ? 0.0f : 0.0f;
		_actuators.control[2] = (PX4_ISFINITE(0.0f)) ? 0.0f : 0.0f;
		_actuators.control[3] = (_spin.get());
		_actuators.control[7] = _v_att_sp.landing_gear;
		
		_actuators.timestamp = hrt_absolute_time();
		_actuators.timestamp_sample = _sensor_gyro.timestamp;
		
		if (!_actuators_0_circuit_breaker_enabled) {
			if (_actuators_0_pub != nullptr) {

				orb_publish(_actuators_id, _actuators_0_pub, &_actuators);

			} else if (_actuators_id) {
				_actuators_0_pub = orb_advertise(_actuators_id, &_actuators);
			}

		}
		*/

	}
	
}

void
MulticopterSMAttitudeControl::run()
{

	/*
	 * do subscriptions
	 */
	_v_att_sub = orb_subscribe(ORB_ID(vehicle_attitude));
	_v_att_sp_sub = orb_subscribe(ORB_ID(vehicle_attitude_setpoint));
	_v_rates_sp_sub = orb_subscribe(ORB_ID(vehicle_rates_setpoint));
	_v_control_mode_sub = orb_subscribe(ORB_ID(vehicle_control_mode));
	_params_sub = orb_subscribe(ORB_ID(parameter_update));
	_manual_control_sp_sub = orb_subscribe(ORB_ID(manual_control_setpoint));
	_vehicle_status_sub = orb_subscribe(ORB_ID(vehicle_status));
	_motor_limits_sub = orb_subscribe(ORB_ID(multirotor_motor_limits));
	_battery_status_sub = orb_subscribe(ORB_ID(battery_status));
	_local_position_sp_sub = orb_subscribe( ORB_ID( vehicle_local_position_setpoint ));
	_local_position_sub = orb_subscribe( ORB_ID( vehicle_local_position ) );
	_gyro_count = math::min(orb_group_count(ORB_ID(sensor_gyro)), MAX_GYRO_COUNT);

	if (_gyro_count == 0) {
		_gyro_count = 1;
	}

	for (unsigned s = 0; s < _gyro_count; s++) {
		_sensor_gyro_sub[s] = orb_subscribe_multi(ORB_ID(sensor_gyro), s);
	}

	_sensor_correction_sub = orb_subscribe(ORB_ID(sensor_correction));
	_sensor_bias_sub = orb_subscribe(ORB_ID(sensor_bias));
	_vehicle_land_detected_sub = orb_subscribe(ORB_ID(vehicle_land_detected));

	/* wakeup source: gyro data from sensor selected by the sensor app */
	px4_pollfd_struct_t poll_fds = {};
	poll_fds.events = POLLIN;

	const hrt_abstime task_start = hrt_absolute_time();
	hrt_abstime last_run = task_start;
	float dt_accumulator = 0.f;
	int loop_counter = 0;

	while (!should_exit()) {

		poll_fds.fd = _sensor_gyro_sub[_selected_gyro];

		/* wait for up to 100ms for data */
		int pret = px4_poll(&poll_fds, 1, 100);

		/* timed out - periodic check for should_exit() */
		if (pret == 0) {
			continue;
		}

		/* this is undesirable but not much we can do - might want to flag unhappy status */
		if (pret < 0) {
			PX4_ERR("poll error %d, %d", pret, errno);
			/* sleep a bit before next try */
			usleep(100000);
			continue;
		}

		perf_begin(_loop_perf);

		/* run controller on gyro changes */
		if (poll_fds.revents & POLLIN) {
			const hrt_abstime now = hrt_absolute_time();
			float dt = (now - last_run) / 1e6f;
			last_run = now;

			/* guard against too small (< 2ms) and too large (> 20ms) dt's */
			if (dt < 0.002f) {
				dt = 0.002f;

			} else if (dt > 0.02f) {
				dt = 0.02f;
			}

			/* copy gyro data */
			orb_copy(ORB_ID(sensor_gyro), _sensor_gyro_sub[_selected_gyro], &_sensor_gyro);

			/* check for updates in other topics */
			parameter_update_poll();
			vehicle_control_mode_poll();
			vehicle_manual_poll();
			vehicle_status_poll();
			vehicle_motor_limits_poll();
			battery_status_poll();
			vehicle_attitude_poll();
			sensor_correction_poll();
			sensor_bias_poll();
			vehicle_land_detected_poll();
			local_position_sp_poll();
			local_position_poll();

			control_attitude_sm(dt);
		
			/* calculate loop update rate while disarmed or at least a few times (updating the filter is expensive) */
			if (!_v_control_mode.flag_armed || (now - task_start) < 3300000) {
				dt_accumulator += dt;
				++loop_counter;

				if (dt_accumulator > 1.f) {
					const float loop_update_rate = (float)loop_counter / dt_accumulator;
					_loop_update_rate_hz = _loop_update_rate_hz * 0.5f + loop_update_rate * 0.5f;
					dt_accumulator = 0;
					loop_counter = 0;
					_lp_filters_d[0].set_cutoff_frequency(_loop_update_rate_hz, _d_term_cutoff_freq.get());
					_lp_filters_d[1].set_cutoff_frequency(_loop_update_rate_hz, _d_term_cutoff_freq.get());
					_lp_filters_d[2].set_cutoff_frequency(_loop_update_rate_hz, _d_term_cutoff_freq.get());
				}
			}

		}

		perf_end(_loop_perf);
	}

	orb_unsubscribe(_v_att_sub);
	orb_unsubscribe(_v_att_sp_sub);
	orb_unsubscribe(_v_rates_sp_sub);
	orb_unsubscribe(_v_control_mode_sub);
	orb_unsubscribe(_params_sub);
	orb_unsubscribe(_manual_control_sp_sub);
	orb_unsubscribe(_vehicle_status_sub);
	orb_unsubscribe(_motor_limits_sub);
	orb_unsubscribe(_battery_status_sub);

	for (unsigned s = 0; s < _gyro_count; s++) {
		orb_unsubscribe(_sensor_gyro_sub[s]);
	}

	orb_unsubscribe(_sensor_correction_sub);
	orb_unsubscribe(_sensor_bias_sub);
	orb_unsubscribe(_vehicle_land_detected_sub);
}

int MulticopterSMAttitudeControl::task_spawn(int argc, char *argv[])
{
	_task_id = px4_task_spawn_cmd("mc_att_control",
					   SCHED_DEFAULT,
					   SCHED_PRIORITY_ATTITUDE_CONTROL,
					   1700,
					   (px4_main_t)&run_trampoline,
					   (char *const *)argv);

	if (_task_id < 0) {
		_task_id = -1;
		return -errno;
	}

	return 0;
}

MulticopterSMAttitudeControl *MulticopterSMAttitudeControl::instantiate(int argc, char *argv[])
{
	return new MulticopterSMAttitudeControl();
}

int MulticopterSMAttitudeControl::custom_command(int argc, char *argv[])
{
	return print_usage("unknown command");
}

int mc_sm_att_control_main(int argc, char *argv[])
{
	return MulticopterSMAttitudeControl::main(argc, argv);
}